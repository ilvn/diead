#ifndef _RNG_UTIL_H_
#define _RNG_UTIL_H_



#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


typedef unsigned int    uniform;    

typedef unsigned long   counter;

typedef double          real;


/* Define constants */

#define DIM       4096

#define UNIMAX    4294967296.   /*pow(2,32)*/

#undef PI

#define PI      3.141592653589793


/* Define Macros */

#define MAX(a, b)  ( (a)<(b) ? (b):(a) )

#define MIN(a, b)  ( (a)<(b) ? (a):(b) )

#define ABS(x)     ( (x)>0 ? (x):(-(x)) )

#define SIGN(x)    ( (x)>0 ? 1:(-1) )


/* Functions provided by PK1 */

uniform uni(char *filename);

double Phi(double z);

double Chisq(int df, double chsq);

double Chisq2( double d, double z); 

double Poisson(double lambda, int k);

float kstest(float[],int);  /* Anderson-Darling version, K-S test.*/

int comp(const void *i,const void *j);

int ucmpr( const void *i1, const void *i2);

#endif /* _RNG_UTIL_H_ */