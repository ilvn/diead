/*
 *	Filenaem: RNGmain.c
 */



#include <stdio.h>
#include "RNGTest.h"
#include "RNGUtil.h"



/*** A pool of random number generators *************************************************/
/* A few sample random number generators for demonstration purpse                       */


/* A efficient and well know 32-bit congruential generator with modulo equal to  2^32.  */
/*   Itself alone is not satisfactory in nowadays application */
unsigned long cong() {
	static unsigned long x = 123456789;

	x = 69069 * x + 1234567L;
	return x;

}	/* cong() */


/* A 3-round shift register generator developed by G. Marsaglia. Marginally satisfactory.*/
unsigned long shr3() {
	static unsigned long jsr = 123456789;

	jsr ^= (jsr<<13);
	jsr ^= (jsr>>17); 
	jsr ^= (jsr<<5);
	return  jsr; 

}	/* shr3() */


/* An enhanced version of the shr3(). The sum of the newly generator values and the */
/* preceding value is returned. Performs a little bit better than shr3().           */                                            
unsigned long shr3plus() {
	static unsigned long j, jsr = 123456789;

	j = jsr;
	jsr ^= (jsr<<13);
	jsr ^= (jsr>>17); 
	jsr ^= (jsr<<5);
	return  j + jsr;

}	/* shr3plus() */


/* A lagged Fibonacci generators that keeps only two preceding values. */
/* A poor generator included for demonstration purpose.                */
unsigned long fib() {
	static unsigned long a = 87654321, b = 7779999;
	
	b = a + b;
	a = b - a;
	return b;
}


/* The KISS generator. The name stands for Keep It Stupid Simple.  */
/* Developed and promoted by G, Marsaglia in recent year           */
unsigned long kiss() 
{
	static unsigned long jsr_m=123456789L, jcong_m=380116160L;

	static unsigned long ix_m=75645113, iy_m=363426069, ic_m=0;

	unsigned long SHR3, CONG, DWC, jj, iz;

	jj = jsr_m; 
	jsr_m ^= jsr_m<<13; 
	jsr_m ^= jsr_m>>17;
	jsr_m ^= jsr_m<<5;
	SHR3 = jj + jsr_m;

	CONG = (jcong_m = 69069L * jcong_m + 1234567L);

	iz = ix_m + iy_m; 
	ix_m = (iz>>15) + ((iz<iy_m)?131072:0);	
	iz = (iz<<17) + ic_m;
	ic_m = ix_m + (iz<ic_m);
	ix_m = iy_m;
	DWC = (iy_m=iz);

	return (DWC ^ CONG) + SHR3;

}	/* kiss() */

/***** End of the sample RNGs **********************************************************/



//A sample program
int main()
{
        printf("\n@@@@@ Maurer's test on fib():  p is %6.4f\n\n\n", maurer(fib) );

        printf("\n@@@@@ Frequency test on fib():  p is %6.4f\n\n\n", frequency(fib) );

        printf("\n@@@@@ Frequency test on cong():  p is %6.4f\n\n\n",frequency( cong) );

        printf("\n@@@@@ GCD test on cong():  p is %6.4f\n\n\n", gcd( cong) );

        printf("\n@@@@@ Birthday spacing test on cong():  p is %6.4f\n\n\n", bday( cong) );

        printf("\n@@@@@ Birthday spacing test on shr3():  p is %6.4f\n\n\n", bday( shr3) );

        printf("\n@@@@@ Gorilla test on cong():  p is %6.4f\n\n\n", gorilla( cong) );

        printf("\n@@@@@ Collision test on kiss():  p is %6.4f\n\n\n", collision( shr3) );

        return 0;
}
